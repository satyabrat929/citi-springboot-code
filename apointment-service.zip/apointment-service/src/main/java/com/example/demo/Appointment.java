package com.example.demo;

public class Appointment {
	
	private String trainerPreference;
	private Boolean physioRequired;
	
}
