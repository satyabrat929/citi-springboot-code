package com.example.demo;

public class PackageDetails {
 private String packageName;
 private Integer noofWeeks;
 private Float charges;
 
public String getPackageName() {
	return packageName;
}
public void setPackageName(String packageName) {
	this.packageName = packageName;
}
public Integer getNoofWeeks() {
	return noofWeeks;
}
public void setNoofWeeks(Integer noofWeeks) {
	this.noofWeeks = noofWeeks;
}
public Float getCharges() {
	return charges;
}
public void setCharges(Float charges) {
	this.charges = charges;
}
 
}
