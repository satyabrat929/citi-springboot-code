package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/appointment")
public class AppointmentController {
	@Autowired
	AppointmentService appointmentService;
	
	@PostMapping("/createappointment")
	@ResponseStatus(code = HttpStatus.CREATED)
	public String createAppointment(@RequestBody Appointment appointment)
	{
		return appointmentService.saveAppointment(appointment);
		//return "appointment booked successfully";
	}
	
	@GetMapping("/viewappointments")
	public AppointmentDtos getAppointments()
	{
		System.out.println("In appointmentDtos");
		return appointmentService.getAppointments();
		
	}
    
	@GetMapping("/viewappointmentbyid")
	public AppointmentDtos getAppointments(Integer Id)
	{
		System.out.println("In appointmentDtos");
		return new AppointmentDtos();
	}
}
