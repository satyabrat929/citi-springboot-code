package com.example.demo;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class AppointmentService {
 
	public String saveAppointment(Appointment appointment) {
		return "appointment saved";
	}
	
	public AppointmentDtos getAppointments(){
		AppointmentDtos appointMentDtos = new AppointmentDtos();
		appointMentDtos.setAppointDetails(new ArrayList<Appointment>());
		return appointMentDtos;
	}
}
