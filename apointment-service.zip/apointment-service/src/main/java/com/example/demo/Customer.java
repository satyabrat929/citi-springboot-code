package com.example.demo;

public class Customer {
 private String Name;
 private Integer age;
 private String mobileNo;
 private String email;
 
 private PackageDetails packageDetails;
 private Address address;
}
