package com.example.demo;

import java.util.List;

public class AppointmentDtos {
  List<Appointment> appointDetails;

public List<Appointment> getAppointDetails() {
	return appointDetails;
}

public void setAppointDetails(List<Appointment> appointDetails) {
	this.appointDetails = appointDetails;
}
}
