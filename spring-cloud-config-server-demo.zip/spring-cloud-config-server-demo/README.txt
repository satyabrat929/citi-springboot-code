
http://localhost:8888/config-server-client/development

http://localhost:8080/getMessage

force refresh properties on target service
send a post request to http://localhost:8080/actuator/refresh   


 


